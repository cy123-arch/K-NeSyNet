import argparse, pandas as pd
from knesynet.preprocessing.text_filter import TreatmentLexicon, filter_document, document_audit_row

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--documents", required=True)
    ap.add_argument("--aliases", required=True)
    ap.add_argument("--out-documents", default="data/text_filtered.csv")
    ap.add_argument("--out-audit", default="data/text_filter_audit.csv")
    args = ap.parse_args()
    df = pd.read_csv(args.documents)
    lex = TreatmentLexicon.from_alias_csv(args.aliases)
    filtered_rows, audit_rows = [], []
    for r in df.itertuples(index=False):
        filtered, removed = filter_document(r.text, lex)
        filtered_rows.append({"case_id": r.case_id, "document_id": r.document_id, "text": filtered})
        audit_rows.append(document_audit_row(
            r.case_id, r.document_id, r.document_date, r.index_date, r.text, filtered, removed
        ))
    pd.DataFrame(filtered_rows).to_csv(args.out_documents, index=False)
    pd.DataFrame(audit_rows).to_csv(args.out_audit, index=False)

if __name__ == "__main__":
    main()
